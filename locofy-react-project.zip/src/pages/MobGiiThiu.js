import "./MobGiiThiu.css";

const MobGiiThiu = () => {
  return (
    <div className="mob-gii-thiu">
      <img className="twitter-icon8" alt="" src="/twitter2.svg" />
      <img className="google-icon7" alt="" src="/google@2x.png" />
      <img className="facebook-icon9" alt="" src="/facebook2.svg" />
      <section className="frame-parent38">
        <div className="frame-wrapper29">
          <div className="frame-parent39">
            <div className="frame-parent40">
              <div className="frame-parent41">
                <div className="frame-wrapper30">
                  <div className="frame-parent42">
                    <div className="bx-menu-wrapper">
                      <img className="bx-menu-icon" alt="" src="/bxmenu.svg" />
                    </div>
                    <img
                      className="menu-open-btn-icon"
                      alt=""
                      src="/menu-open-btn.svg"
                    />
                  </div>
                </div>
                <div className="frame-child61" />
              </div>
              <div className="frame-wrapper31">
                <section className="frame-parent43">
                  <img className="frame-child62" alt="" src="/group-168.svg" />
                  <img
                    className="frame-child63"
                    loading="lazy"
                    alt=""
                    src="/line-31.svg"
                  />
                </section>
              </div>
            </div>
            <div className="frame-wrapper32">
              <div className="frame-parent44">
                <div className="frame-parent45">
                  <div className="wrapper">
                    <img className="icon" alt="" src="/1.svg" />
                  </div>
                  <div className="nhiu-n-lc-parent1">
                    <img className="nhiu-n-lc9" alt="" src="/nhiu-n-lc.svg" />
                    <div className="nim-tin-wrapper">
                      <img
                        className="nim-tin-icon"
                        loading="lazy"
                        alt=""
                        src="/nim-tin.svg"
                      />
                    </div>
                  </div>
                  <div className="frame-child64" />
                </div>
                <div className="frame-parent46">
                  <div className="ellipse-frame">
                    <div className="frame-child65" />
                  </div>
                  <button className="button-button-normal11">
                    <div className="rectangle11" />
                    <b className="follow-us3">FOLLOW US</b>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="frame-parent47">
          <div className="frame-parent48">
            <div className="frame-parent49">
              <div className="cng-ty-tnhh-cng-ngh-maia-ma-group">
                <div className="cng-ty-tnhh-container2">
                  <span className="cng-ty-tnhh-container3">
                    <p className="cng-ty-tnhh-cng-ngh-maia2">
                      <b>Công ty TNHH Công nghệ MaiA</b>
                    </p>
                    <p className="maia-technology-coltd-maiate2">
                      <b>MaiA Technology Co.Ltd (MaiATech)</b>
                    </p>
                    <p className="blank-line46">
                      <b>&nbsp;</b>
                    </p>
                    <p className="cng-ty-maiatech1">
                      Công ty MaiaTech được thành lập vào ngày
                    </p>
                    <p className="nm-20151">năm 2015 .........</p>
                    <p className="cng-ty-tnhh1">
                      Công ty TNHH Công nghệ Mai A, chuyên cung cấp giải pháp
                      phân tích thiết kế hệ thống và xây dựng phần mềm ứng dụng
                      theo yêu cầu. Bao gồm ứng dụng mobile, ứng dụng web, ứng
                      dụng desktop. Sau một thời gian lắng nghe yêu cầu từ phía
                      khách hàng, với sự trao đổi, tư vấn của Mai A, hai bên sẽ
                      đề ra các yêu cầu và tiến độ thực hiện công việc. Cho đến
                      nay, các sản phẩm của công ty đều đạt tiến độ và chất
                      lượng đề ra.
                    </p>
                  </span>
                </div>
                <section className="rectangle-parent16">
                  <div className="frame-child66" />
                  <img
                    className="mask-group-icon18"
                    alt=""
                    src="/mask-group-31@2x.png"
                  />
                  <img
                    className="mask-group-icon19"
                    alt=""
                    src="/mask-group-41@2x.png"
                  />
                  <img
                    className="mask-group-icon20"
                    alt=""
                    src="/mask-group-51@2x.png"
                  />
                  <img
                    className="mask-group-icon21"
                    alt=""
                    src="/mask-group-13@2x.png"
                  />
                  <img
                    className="mask-group-icon22"
                    alt=""
                    src="/mask-group-21@2x.png"
                  />
                  <img
                    className="frame-child67"
                    loading="lazy"
                    alt=""
                    src="/group-113.svg"
                  />
                  <div className="frame-child68" />
                </section>
              </div>
              <div className="frame-wrapper33">
                <div className="frame-parent50">
                  <div className="button-button-normal-frame">
                    <button className="button-button-normal12">
                      <div className="rectangle12" />
                      <div className="read-more1">Read more</div>
                    </button>
                  </div>
                  <div className="frame-child69" />
                  <img
                    className="frame-child70"
                    loading="lazy"
                    alt=""
                    src="/line-2.svg"
                  />
                </div>
              </div>
            </div>
            <div className="frame-wrapper34">
              <div className="frame-parent51">
                <div className="frame-parent52">
                  <div className="what-we-do-container">
                    <h1 className="what-we-do1">what we do</h1>
                  </div>
                  <div className="vi-quy-trnh1">
                    Với quy trình làm việc khoa học từng bước một, maiatech sẽ
                    cùng bạn giải quyết tất cả các vấn để với phương châm “Your
                    Problem, Our Solution”
                  </div>
                </div>
                <div className="frame-parent53">
                  <div className="ideal-container">
                    <b className="ideal1">ideal</b>
                  </div>
                  <div className="frame-parent54">
                    <div className="frame-wrapper35">
                      <div className="ellipse-parent5">
                        <div className="frame-child71" />
                        <img
                          className="frame-child72"
                          alt=""
                          src="/group-106@2x.png"
                        />
                        <img
                          className="frame-child73"
                          alt=""
                          src="/group-106@2x.png"
                        />
                        <img
                          className="frame-child74"
                          alt=""
                          src="/group-108@2x.png"
                        />
                        <img
                          className="frame-child75"
                          alt=""
                          src="/group-106@2x.png"
                        />
                      </div>
                    </div>
                    <div className="frame-parent55">
                      <div className="frame-parent56">
                        <div className="brain-1-wrapper">
                          <img
                            className="brain-1-icon1"
                            alt=""
                            src="/brain-1.svg"
                          />
                        </div>
                        <div className="lorem-ipsum-is9">{`Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever `}</div>
                      </div>
                      <div className="frame-parent57">
                        <div className="strategy-container">
                          <b className="strategy1">strategy</b>
                        </div>
                        <div className="frame-parent58">
                          <div className="user-1-wrapper">
                            <img
                              className="user-1-icon1"
                              alt=""
                              src="/user-11.svg"
                            />
                          </div>
                          <div className="lorem-ipsum-is10">{`Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever `}</div>
                        </div>
                      </div>
                      <div className="frame-parent59">
                        <div className="design-container">
                          <b className="design1">design</b>
                        </div>
                        <div className="frame-parent60">
                          <div className="vector-1-wrapper">
                            <img
                              className="vector-1-icon1"
                              alt=""
                              src="/vector-1.svg"
                            />
                          </div>
                          <div className="lorem-ipsum-is11">{`Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever `}</div>
                        </div>
                      </div>
                      <div className="frame-parent61">
                        <div className="development-container">
                          <b className="development3">development</b>
                        </div>
                        <div className="frame-parent62">
                          <div className="development-1-wrapper">
                            <img
                              className="development-1-icon1"
                              alt=""
                              src="/development-11.svg"
                            />
                          </div>
                          <div className="lorem-ipsum-is12">{`Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever `}</div>
                        </div>
                      </div>
                      <div className="frame-parent63">
                        <div className="product-container">
                          <b className="product1">product</b>
                        </div>
                        <div className="frame-parent64">
                          <div className="new-product-1-wrapper">
                            <img
                              className="new-product-1-icon1"
                              alt=""
                              src="/newproduct-11.svg"
                            />
                          </div>
                          <div className="lorem-ipsum-is13">{`Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever `}</div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="mask-group-wrapper">
            <img
              className="mask-group-icon23"
              alt=""
              src="/mask-group@2x.png"
            />
          </div>
        </div>
      </section>
      <section className="mob-gii-thiu-inner">
        <div className="frame-parent65">
          <img
            className="frame-child76"
            loading="lazy"
            alt=""
            src="/group-172@2x.png"
          />
          <div className="frame-wrapper36">
            <div className="frame-parent66">
              <img className="frame-child77" alt="" src="/group-107-1.svg" />
              <div className="vi-nh-hng-chin-lc-tron-container">
                <div className="vi-nh-hng1">
                  Với định hướng chiến lược trong vòng 10 năm, MaiATech phấn đấu
                  trở thành công ty chuyên nghiệp hàng đầu Việt Nam trong các
                  lĩnh vực cung cấp ứng dụng phần mềm trên nền tảng Internet.
                  Góp phần tăng năng suất, hiệu quả cho nền kinh tế, hướng tới
                  phát triển có chiều sâu, MaiATech đã và đang tập trung năng
                  lực chuyên môn và nguồn lực tài chính cho các lĩnh vực hoạt
                  động sau
                </div>
              </div>
              <div className="frame-wrapper37">
                <div className="frame-parent67">
                  <div className="frame-wrapper38">
                    <div className="frame-parent68">
                      <div className="outline-wrapper">
                        <img
                          className="outline-icon1"
                          loading="lazy"
                          alt=""
                          src="/outline.svg"
                        />
                      </div>
                      <b className="phn-mm-qun4">Phần mềm quản lý</b>
                    </div>
                  </div>
                  <div className="phn-mm-qun-container1">
                    <span>
                      <p className="phn-mm-qun5">
                        + Phần mềm Quản lý nhân sự - HRM
                      </p>
                      <p className="phn-mm-qun6">
                        + Phần mềm Quản lý công văn – Doc
                      </p>
                      <p className="phn-mm-qun7">
                        + Phần mềm Quản lý khách hàng – Customer
                      </p>
                      <p className="phn-mm-k1">
                        + Phần mềm Kế toán - Accounting
                      </p>
                    </span>
                  </div>
                </div>
              </div>
              <div className="frame-wrapper39">
                <div className="frame-parent69">
                  <div className="settings-1-wrapper">
                    <img
                      className="settings-1-icon1"
                      loading="lazy"
                      alt=""
                      src="/settings-11.svg"
                    />
                  </div>
                  <b className="t-vn-thit-container2">
                    <p className="t-vn-thit4">{`Tư vấn, thiết kế website, `}</p>
                    <p className="gii-php-tmt1">giải pháp TMĐT</p>
                  </b>
                </div>
              </div>
              <div className="t-vn-thit-k-website-gii-t-wrapper">
                <div className="t-vn-thit-container3">
                  <span>
                    <p className="t-vn-thit5">
                      + Tư vấn thiết kế website giới thiệu doanh nghiệp
                    </p>
                    <p className="t-vn-thit6">
                      + Tư vấn thiết kế website bán hàng
                    </p>
                    <p className="t-vn-thit7">
                      + Tư vấn thiết kế và cung cấp giải pháp TMĐT
                    </p>
                    <p className="h-tr-k1">
                      + Hỗ trợ kỹ thuật và cung cấp giải pháp xử lý sự cố
                    </p>
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <section className="mob-gii-thiu-child">
        <div className="frame-parent70">
          <div className="frame-wrapper40">
            <div className="frame-parent71">
              <div className="database-server-wrapper">
                <img
                  className="database-server-icon1"
                  loading="lazy"
                  alt=""
                  src="/database-server1.svg"
                />
              </div>
              <b className="domain-hosting-vps-container1">
                <p className="domain-hosting1">{`Domain, hosting, `}</p>
                <p className="vps-email1">VPS, email</p>
              </b>
            </div>
          </div>
          <div className="ng-k-gia-container1">
            <span>
              <p className="ng-k-gia1">+ Đăng ký, gia hạn tên miền (domain)</p>
              <p className="cho-thu-hosting1">+ Cho thuê hosting</p>
              <p className="cho-thu-my1">+ Cho thuê máy chủ ảo (VPS)</p>
              <p className="cho-thu-email1">+ Cho thuê email server</p>
            </span>
          </div>
        </div>
      </section>
      <section className="mob-gii-thiu-inner1">
        <div className="frame-parent72">
          <div className="frame-parent73">
            <img
              className="frame-child78"
              loading="lazy"
              alt=""
              src="/group-134.svg"
            />
            <div className="frame-wrapper41">
              <div className="pht-trin-ng-dng-chng-tr-parent">
                <div className="pht-trin-ng-container2">
                  <p className="pht-trin-ng1">
                    Phát triển ứng dụng, chương trình đa nền tảng
                  </p>
                </div>
                <div className="frame-parent74">
                  <img
                    className="frame-child79"
                    loading="lazy"
                    alt=""
                    src="/group-1152@2x.png"
                  />
                  <div className="frame-child80" />
                </div>
              </div>
            </div>
          </div>
          <div className="frame-wrapper42">
            <div className="desktop-development-parent">
              <b className="desktop-development1">desktop development</b>
              <div className="lorem-ipsum-is-simply-dummy-te-wrapper">
                <div className="lorem-ipsum-is14">{`Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever `}</div>
              </div>
              <div className="ellipse-parent6">
                <div className="frame-child81" />
                <img
                  className="group-icon2"
                  loading="lazy"
                  alt=""
                  src="/group.svg"
                />
              </div>
            </div>
          </div>
        </div>
      </section>
      <section className="group-section">
        <div className="line-6-stroke-parent">
          <img className="line-6-stroke" alt="" src="/line-6-stroke.svg" />
          <div className="wrapper-ellipse-9">
            <img
              className="wrapper-ellipse-9-child"
              alt=""
              src="/ellipse-9.svg"
            />
          </div>
          <div className="wrapper-ellipse-9-stroke">
            <img
              className="ellipse-9-stroke"
              alt=""
              src="/ellipse-9-stroke.svg"
            />
          </div>
          <img
            className="frame-child82"
            loading="lazy"
            alt=""
            src="/group-88.svg"
          />
          <img
            className="to-cc-ng-dng-web-chy-t"
            loading="lazy"
            alt=""
            src="/to-cc-ng-dng-web--chy-trn-mi-trng-trnh-duyt-web.svg"
          />
          <img
            className="coding-1-icon1"
            loading="lazy"
            alt=""
            src="/coding-11.svg"
          />
        </div>
      </section>
      <section className="mob-gii-thiu-inner2">
        <section className="frame-parent75">
          <div className="mobile-development-group">
            <b className="mobile-development1">mobile development</b>
            <div className="tao-ra-phn-mm-ng-dng-mobil-container">
              <div className="tao-ra-phn1">{`tao ra phần mềm ứng dụng mobile được người dùng mua thông qua các “cửa hàng ứng dụng” như Google Play, App Store, CH Play,… `}</div>
            </div>
            <div className="ellipse-parent7">
              <div className="frame-child83" />
              <img
                className="frame-child84"
                loading="lazy"
                alt=""
                src="/group-1491.svg"
              />
            </div>
          </div>
          <div className="frame-wrapper43">
            <div className="rectangle-parent17">
              <div className="frame-child85" />
              <div className="nhn-bo-gi-t-vn-trc-ti-parent">
                <h1 className="nhn-bo-gi2">{`Nhận báo giá & tư vấn trực tiếp`}</h1>
                <button className="rectangle-parent18">
                  <div className="frame-child86" />
                  <div className="tn-ca-bn2">Tên của bạn *</div>
                </button>
              </div>
              <div className="rectangle-parent19">
                <div className="frame-child87" />
                <div className="email10">Email *</div>
              </div>
              <button className="rectangle-parent20">
                <div className="frame-child88" />
                <div className="cng-ty1">Công ty *</div>
              </button>
              <button className="rectangle-parent21">
                <div className="frame-child89" />
                <div className="nhn-bo-gi3">Nhận báo giá</div>
              </button>
            </div>
          </div>
          <div className="frame-wrapper44">
            <div className="frame-parent76">
              <img
                className="frame-child90"
                loading="lazy"
                alt=""
                src="/group-150.svg"
              />
              <div className="chuyn-nhu-cu-ca-ngi-dng-wrapper">
                <div className="chuyn-nhu-cu1">
                  Chuyển nhu cầu của người dùng hoặc mục tiêu tiếp thị thành một
                  sản phẩm phần mềm (sofware)
                </div>
              </div>
            </div>
          </div>
          <div className="frame-parent77">
            <div className="frame-parent78">
              <div className="fixed-project-wrapper">
                <b className="fixed-project1">fixed project</b>
              </div>
              <div className="lorem-ipsum-is15">{`Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever `}</div>
              <div className="ellipse-parent8">
                <div className="frame-child91" />
                <img
                  className="bug-1-icon1"
                  loading="lazy"
                  alt=""
                  src="/bug-11.svg"
                />
              </div>
            </div>
            <div className="wrapper-group-185-parent">
              <div className="wrapper-group-185">
                <img
                  className="wrapper-group-185-child"
                  alt=""
                  src="/group-185.svg"
                />
              </div>
              <div className="network-1-wrapper">
                <img
                  className="network-1-icon1"
                  loading="lazy"
                  alt=""
                  src="/network-11.svg"
                />
              </div>
              <div className="frame-parent79">
                <div className="frame-wrapper45">
                  <img className="frame-child92" alt="" src="/group-88-1.svg" />
                </div>
                <img
                  className="lorem-ipsum-is-simply-dummy-te"
                  loading="lazy"
                  alt=""
                  src="/lorem-ipsum-is-simply-dummy-text-of-the-printing-and-typesetting-industry-lorem-ipsum-has-been-the-industrys-standard-dummy-text-ever.svg"
                />
              </div>
            </div>
            <div className="managed-services-group">
              <b className="managed-services1">managed services</b>
              <div className="dch-v-c1">
                Dịch vụ được quản lý là thực hành thuê ngoài trên cơ sở chủ động
                các quy trình và chức năng nhất định nhằm cải thiện hoạt động và
                cắt giảm chi phí
              </div>
              <div className="ellipse-parent9">
                <div className="frame-child93" />
                <img
                  className="process-1-icon1"
                  loading="lazy"
                  alt=""
                  src="/process-11.svg"
                />
              </div>
            </div>
          </div>
        </section>
      </section>
      <img className="mask-group-icon24" alt="" src="/mask-group-61@2x.png" />
      <section className="frame-parent80">
        <div className="frame-wrapper46">
          <div className="frame-parent81">
            <div className="meet-our-team-wrapper">
              <h1 className="meet-our-team1">meet our team</h1>
            </div>
            <div className="mt-s-thnh1">
              Một số thành viên chủ chốt trong đội ngũ
            </div>
          </div>
        </div>
        <div className="frame-parent82">
          <div className="frame-parent83">
            <div className="rectangle-parent22">
              <div className="frame-child94" />
              <img
                className="mask-group-icon25"
                alt=""
                src="/mask-group-71@2x.png"
              />
            </div>
            <div className="ks-cntt-l-sn-tng-container">
              <b className="ks-cntt-l1">KS CNTT Lê Sơn Tùng</b>
            </div>
            <div className="pg-pt-khch1">PGĐ PT Khách hàng dự án</div>
          </div>
          <div className="frame-wrapper47">
            <div className="frame-parent84">
              <div className="wrapper-group-122-group">
                <div className="wrapper-group-1221">
                  <img
                    className="wrapper-group-122-item"
                    loading="lazy"
                    alt=""
                    src="/group-1221@2x.png"
                  />
                </div>
                <b className="ths-cntt-l1">ThS CNTT Lê Doãn Phước</b>
              </div>
              <div className="gim-c-container">
                <div className="gim-c1">Giám đốc</div>
              </div>
            </div>
          </div>
          <div className="rectangle-parent23">
            <div className="frame-child95" />
            <img
              className="mask-group-icon26"
              alt=""
              src="/mask-group-81@2x.png"
            />
            <div className="frame-wrapper48">
              <div className="frame-parent85">
                <div className="ths-v-hu-dng-container">
                  <b className="ths-v-hu1">ThS Vũ Hữu Dũng</b>
                </div>
                <div className="trng-phng-h1">
                  Trưởng phòng Hệ thống thông tin
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="frame-wrapper49">
          <div className="rectangle-parent24">
            <div className="frame-child96" />
            <div className="frame-child97" />
            <div className="frame-child98" />
          </div>
        </div>
      </section>
      <section className="mask-group-parent3">
        <img className="mask-group-icon27" alt="" src="/mask-group-91@2x.png" />
        <div className="maiatech-parent5">
          <img className="maiatech-icon15" alt="" src="/maiatech.svg" />
          <img className="maiatech-icon16" alt="" src="/maiatech.svg" />
        </div>
        <img className="twitter-icon9" alt="" src="/twitter-13.svg" />
        <img className="google-icon8" alt="" src="/google-1@2x.png" />
        <img className="facebook-icon10" alt="" src="/facebook-11.svg" />
        <div className="frame-child99" />
        <div className="frame-child100" />
        <img className="frame-child101" alt="" src="/group-115@2x.png" />
        <div className="frame-child102" />
      </section>
      <div className="frame-parent86">
        <div className="rectangle-parent25">
          <div className="frame-child103" />
          <section className="frame-parent87">
            <div className="your-problem-wrapper">
              <h1 className="your-problem3">
                <span>
                  <p className="your">{`Your `}</p>
                  <p className="problem">Problem.</p>
                </span>
              </h1>
            </div>
            <h1 className="our-solotution">
              <span>
                <p className="our2">{`Our `}</p>
                <p className="solotution">Solotution.</p>
              </span>
            </h1>
          </section>
          <div className="button-button-normal-wrapper1">
            <button className="button-button-normal13">
              <div className="rectangle13" />
              <div className="contact-us6">Contact Us</div>
            </button>
          </div>
          <div className="frame-wrapper50">
            <div className="rectangle-parent26">
              <div className="frame-child104" />
              <div className="rectangle-parent27">
                <div className="frame-child105" />
                <div className="frame-child106" />
              </div>
            </div>
          </div>
        </div>
        <section className="frame-wrapper51">
          <div className="frame-parent88">
            <div className="nhiu-n-lc-mt-nim-tin-wrapper2">
              <div className="nhiu-n-lc10">nhiều nỗ lực - một niềm tin</div>
            </div>
            <div className="hotline-0936-468-container4">
              <p className="hotline8">
                <span className="hotline9">
                  <b>hotline</b>
                </span>
              </p>
              <p className="p3">
                <span className="span6">
                  <span className="span7">
                    0936 468 486 - 0979 723 816 0936 468 688 - 0912 922 530
                  </span>
                </span>
              </p>
              <p className="blank-line47">
                <span className="blank-line48">
                  <span className="blank-line49">&nbsp;</span>
                </span>
              </p>
              <p className="email11">
                <span className="email12">
                  <b>email</b>
                </span>
              </p>
              <p className="contactmaiatechcomvn2">
                <span className="contactmaiatechcomvn3">
                  <span>contact@maiatech.com.vn</span>
                </span>
              </p>
              <p className="blank-line50">
                <span className="blank-line51">
                  <b>&nbsp;</b>
                </span>
              </p>
              <p className="address8">
                <span className="address9">
                  <b>address</b>
                </span>
              </p>
              <p className="s-26-ng-cu-vit-1-th-tr6">
                <span className="s-26-ng-cu-vit-1-th-tr7">
                  <span className="s-26-ng3">
                    Số 26 đường Cửu Việt 1, thị trấn Trâu Quỳ, huyện Gia Lâm, Hà
                    Nội
                  </span>
                </span>
              </p>
              <p className="blank-line52">
                <span className="blank-line53">
                  <span className="blank-line54">&nbsp;</span>
                </span>
              </p>
              <p className="blank-line55">
                <span className="blank-line56">
                  <span className="blank-line57">&nbsp;</span>
                </span>
              </p>
            </div>
            <div className="trang-ch-gii-thiu-dch-v-d-parent">
              <div className="trang-ch-gii-container3">
                <p className="trang-ch3">Trang chủ</p>
                <p className="gii-thiu7">Giới thiệu</p>
                <p className="dch-v6">Dịch vụ</p>
                <p className="d-n6">Dự án</p>
                <p className="i-ng6">Đội ngũ</p>
                <p className="blank-line58">&nbsp;</p>
              </div>
              <div className="copyright-maiatech-2020-wrapper1">
                <div className="copyright-maiatech8">
                  {" "}
                  Copyright © MaiATech 2020.
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
};

export default MobGiiThiu;
