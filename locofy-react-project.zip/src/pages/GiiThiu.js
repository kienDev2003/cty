import { useCallback } from "react";
import { useNavigate } from "react-router-dom";
import "./GiiThiu.css";

const GiiThiu = () => {
  const navigate = useNavigate();

  const onMAIATECH1Click = useCallback(() => {
    navigate("/home-page");
  }, [navigate]);

  const onLINHTextClick = useCallback(() => {
    navigate("/");
  }, [navigate]);

  return (
    <div className="gii-thiu4">
      <div className="gii-thiu-child" />
      <img className="gii-thiu-item" alt="" src="/output-generator.svg" />
      <img className="tucozi-icon2" alt="" />
      <div className="tucozi2" />
      <section className="frame-parent35">
        <img
          className="frame-child54"
          loading="lazy"
          alt=""
          src="/group-19.svg"
        />
        <h1 className="maiatech3">MAIATECH</h1>
        <img className="mask-group-icon15" alt="" src="/mask-group@2x.png" />
        <img
          className="frame-child55"
          loading="lazy"
          alt=""
          src="/line-3.svg"
        />
        <img
          className="frame-child56"
          loading="lazy"
          alt=""
          src="/line-4.svg"
        />
        <div className="frame-child57" />
      </section>
      <div className="sub-intro-wrapper">
        <header className="sub-intro">
          <div className="frame-parent36">
            <div className="frame-wrapper28">
              <div className="maiatech-parent3">
                <img className="maiatech-icon9" alt="" src="/maiatech.svg" />
                <div className="social-icons">
                  <img className="maiatech-icon10" alt="" src="/maiatech.svg" />
                  <img
                    className="maiatech-icon11"
                    alt=""
                    src="/maiatech-2.svg"
                    onClick={onMAIATECH1Click}
                  />
                </div>
              </div>
            </div>
            <nav className="gii-thiu-container">
              <div className="gii-thiu5">GIỚI THIỆU</div>
              <div className="dch-v4">DỊCH VỤ</div>
              <div className="d-n4">DỰ ÁN</div>
              <div className="i-ng4">ĐỘI NGŨ</div>
              <div className="lin-h3" onClick={onLINHTextClick}>
                LIÊN HỆ
              </div>
            </nav>
          </div>
          <div className="nhiu-n-lc-mt-nim-tin-wrapper1">
            <div className="nhiu-n-lc6">nhiều nỗ lực - một niềm tin</div>
          </div>
        </header>
      </div>
      <section className="mask-group-parent2">
        <img className="mask-group-icon16" alt="" src="/mask-group-12@2x.png" />
        <div className="hotline-0936-468-container3">
          <p className="hotline5">
            <span className="hotline6">
              <b className="hotline7">hotline</b>
            </span>
          </p>
          <p className="p2">
            <span className="span4">
              <span className="span5">
                0936 468 486 - 0979 723 816 0936 468 688 - 0912 922 530
              </span>
            </span>
          </p>
          <p className="blank-line27">
            <span className="blank-line28">
              <span className="blank-line29">&nbsp;</span>
            </span>
          </p>
          <p className="email7">
            <span className="email8">
              <b className="email9">email</b>
            </span>
          </p>
          <p className="infodolphinhomegmailcom4">
            <a
              className="infodolphinhomegmailcom5"
              href="mailto:contact@maiatech.com.vn"
              target="_blank"
            >
              <span className="infodolphinhomegmailcom6">
                <span className="infodolphinhomegmailcom7">
                  infodolphinhome@gmail.com
                </span>
              </span>
            </a>
          </p>
          <p className="blank-line30">
            <span className="blank-line31">
              <b className="blank-line32">&nbsp;</b>
            </span>
          </p>
          <p className="address5">
            <span className="address6">
              <b className="address7">address</b>
            </span>
          </p>
          <p className="s-26-ng-cu-vit-1-th-tr4">
            <span className="s-26-ng-cu-vit-1-th-tr5">
              <span className="s-26-ng2">
                Số 26 đường Cửu Việt 1, thị trấn Trâu Quỳ, huyện Gia Lâm, Hà Nội
              </span>
            </span>
          </p>
          <p className="blank-line33">
            <span className="blank-line34">
              <span className="blank-line35">&nbsp;</span>
            </span>
          </p>
          <p className="blank-line36">
            <span className="blank-line37">
              <span className="blank-line38">&nbsp;</span>
            </span>
          </p>
        </div>
      </section>
      <img className="mask-group-icon17" alt="" src="/mask-group@2x.png" />
      <section className="logo-container">
        <div className="frame-parent37">
          <div className="contact-us-button-wrapper">
            <div className="contact-us-button">
              <div className="facebook-icon-wrapper">
                <div className="facebook-icon4" />
              </div>
              <div className="copyright-symbol">
                <div className="div2">1</div>
                <div className="twitter-icon4">
                  <div className="google-plus-icon">
                    <div className="linked-in-icon">
                      <div className="button-button-normal8">
                        <div className="rectangle8" />
                        <div className="contact-us4">CONTACT US</div>
                      </div>
                      <button className="button-button-normal9">
                        <div className="rectangle9" />
                        <b className="follow-us2">FOLLOW US</b>
                      </button>
                    </div>
                    <div className="logo">
                      <img
                        className="facebook-icon5"
                        loading="lazy"
                        alt=""
                        src="/facebook.svg"
                      />
                      <img
                        className="twitter-icon5"
                        loading="lazy"
                        alt=""
                        src="/twitter1.svg"
                      />
                      <img
                        className="google-icon4"
                        loading="lazy"
                        alt=""
                        src="/google@2x.png"
                      />
                    </div>
                    <div className="nhiu-n-lc-container">
                      <h1 className="nhiu-n-lc7">nhiều nỗ lực</h1>
                      <h1 className="nim-tin2">niềm tin</h1>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="button-shape">
            <div className="button-shape-child" />
            <div className="button-shape-inner">
              <div className="introdution-parent">
                <h1 className="introdution">Introdution</h1>
                <div className="font-style">
                  <h1 className="maiatech4"> Maiatech</h1>
                </div>
              </div>
            </div>
            <div className="spacing-control">
              <div className="cng-ty-tnhh-container1">
                <span>
                  <p className="cng-ty-tnhh-cng-ngh-maia1">
                    <b>
                      <span>Công ty TNHH Công nghệ MaiA</span>
                    </b>
                  </p>
                  <p className="maia-technology-coltd-maiate1">
                    <b>
                      <span>{`MaiA Technology Co.Ltd (MaiATech)

`}</span>
                    </b>
                    <span>
                      <b>Niềm tin cốt lõi</b>
                    </span>
                  </p>
                  <p className="nim-tin-v-s-tip-ni">
                    <span>
                      <span className="nim-tin-v">
                        1. Niềm tin về sự tiếp nối:
                      </span>
                    </span>
                  </p>
                  <p className="nh-dng-nc-tun-ra-b-li">
                    <span>
                      <span className="nh-dng-nc">
                        Như dòng nước "tuôn ra bể lại mưa về nguồn", chúng tôi
                        tin rằng không có điều gì hoàn toàn dừng lại, không có
                        cái gì hoàn toàn biến mất, mà chúng liên tục thay đổi,
                        chuyển hóa, phát sinh, để tạo ra chuỗi nhân - quả dài vô
                        tận. Niềm tin đó giúp chúng tôi luôn có trách nhiệm đến
                        cùng với mọi công việc của mình.
                      </span>
                    </span>
                  </p>
                  <p className="blank-line39">
                    <span>
                      <span className="blank-line40">&nbsp;</span>
                    </span>
                  </p>
                  <p className="nim-tin-v-s-lan-ta-ca-nh">
                    <span>
                      <span className="nim-tin-v1">
                        2. Niềm tin về sự lan tỏa của những điều tốt đẹp:
                      </span>
                    </span>
                  </p>
                  <p className="chng-ti-tin-rng-mi-suy-ng">
                    <span>
                      <span className="chng-ti-tin">{`Chúng tôi tin rằng, mỗi suy nghĩ, hành động, thái độ, lời nói tốt đẹp sẽ được lan tỏa ra những người xung quanh, giúp cộng đồng xã hội ngày một tốt đẹp hơn. Từ đó, chúng tôi luôn mong muốn sử dụng công nghệ để tạo nên những giá trị tốt đẹp cho xã hộ
`}</span>
                      <b className="gi-tr-ct">{`
Giá trị cốt lõi`}</b>
                    </span>
                  </p>
                  <p className="vi-khch-hng-i-tc">
                    <span>
                      <span className="vi-khch-hng">
                        1. Với khách hàng, đối tác:
                      </span>
                    </span>
                  </p>
                  <p className="hi-ha-li-ch-cc-bn-u-c">
                    <span>
                      <span className="hi-ha-li">
                        Hài hòa lợi ích, các bên đều có lợi.
                      </span>
                    </span>
                  </p>
                  <p className="trong-ni-b">
                    <span>
                      <span className="trong-ni-b1">2. Trong nội bộ:</span>
                    </span>
                  </p>
                  <p className="dn-ch-trong-tho-lun-nhng">
                    <span>
                      <span className="dn-ch-trong">{`Dân chủ trong thảo luận nhưng thống nhất trong hành động, cái riêng phải phục tùng cái chung, có lý, có tình. Tạo điều kiện cho tất cả mọi người được phát huy năng lực và nhận thành quả tương xứng với hiệu quả công việc của mình.

`}</span>
                      <b className="phng-hng-pht">Phương hướng phát triển</b>
                    </span>
                  </p>
                  <p className="pht-trin-cc-d-n-may-o-th">
                    <span>
                      <span className="pht-trin-cc">
                        1. Phát triển các dự án may đo theo yêu cầu để tích lũy
                        kinh nghiệm, vốn, uy tín, mở rộng danh mục khách hàng.
                      </span>
                    </span>
                  </p>
                  <p className="blank-line41">
                    <span>
                      <span className="blank-line42">&nbsp;</span>
                    </span>
                  </p>
                  <p className="pht-trin-cc-dch-v-theo-m">
                    <span>
                      <span className="pht-trin-cc1">
                        2. Phát triển các dịch vụ theo mô hình "phần mềm như một
                        dịch vụ" (Software as a service - SaaS) trên nền tảng
                        Internet.
                      </span>
                    </span>
                  </p>
                  <p className="blank-line43">
                    <span>
                      <span className="blank-line44">&nbsp;</span>
                    </span>
                  </p>
                  <p className="nghin-cu-pht-trin-cng-ngh">
                    <span>
                      <span className="nghin-cu-pht">
                        3. Nghiên cứu phát triển công nghệ lõi
                      </span>
                    </span>
                  </p>
                </span>
              </div>
              <div className="spacing-control-inner">
                <div className="maiatech-parent4">
                  <img
                    className="maiatech-icon12"
                    loading="lazy"
                    alt=""
                    src="/maiatech-3.svg"
                  />
                  <div className="logo1">
                    <div className="menu-items">
                      <img
                        className="facebook-icon6"
                        loading="lazy"
                        alt=""
                        src="/facebook-12.svg"
                      />
                      <img
                        className="twitter-icon6"
                        loading="lazy"
                        alt=""
                        src="/twitter-12.svg"
                      />
                      <img
                        className="google-icon5"
                        loading="lazy"
                        alt=""
                        src="/google-11@2x.png"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <div className="gii-thiu-inner" />
      <section className="page-title-parent">
        <div className="page-title">
          <div className="page-title-child" />
          <div className="content-area">
            <h1 className="chng-ti-cam-container2">
              <p className="chng-ti-cam2">{`Chúng tôi cam kết mang tới cho `}</p>
              <p className="khch-hng-nhng2">
                Khách hàng những giải pháp chuyên nghiệp nhất !
              </p>
            </h1>
          </div>
          <div className="c-t-a-button">
            <div className="your-problem-container">
              <h1 className="your-problem2">Your Problem.</h1>
              <div className="facebook-icon7">
                <h1 className="our-solution2">Our Solution.</h1>
              </div>
            </div>
          </div>
          <div className="contact-form-container-parent">
            <div className="contact-form-container">
              <button className="button-button-normal10">
                <div className="rectangle10" />
                <div className="contact-us5">Contact Us</div>
              </button>
            </div>
            <div className="rectangle-parent14">
              <div className="frame-child58" />
              <div className="rectangle-parent15">
                <div className="frame-child59" />
                <div className="frame-child60" />
              </div>
            </div>
          </div>
        </div>
        <footer className="banner-container-parent">
          <div className="banner-container">
            <div className="banner-container-child" />
          </div>
          <div className="image">
            <div className="company-info-container">
              <div className="company-name">
                <div className="maii-logo">
                  <div className="team-members">
                    <div className="member-card">
                      <div className="member-image">
                        <img
                          className="maiatech-icon13"
                          alt=""
                          src="/maiatech.svg"
                        />
                        <img
                          className="maiatech-icon14"
                          loading="lazy"
                          alt=""
                          src="/maiatech.svg"
                        />
                      </div>
                    </div>
                    <div className="member-description">
                      <div className="nhiu-n-lc8">
                        nhiều nỗ lực - một niềm tin
                      </div>
                    </div>
                  </div>
                  <div className="client-quote-wrapper">
                    <div className="client-quote">
                      <div className="author-name">
                        <div className="developer-logo">
                          <img
                            className="facebook-icon8"
                            loading="lazy"
                            alt=""
                            src="/facebook-1.svg"
                          />
                          <img
                            className="twitter-icon7"
                            loading="lazy"
                            alt=""
                            src="/twitter-1.svg"
                          />
                          <img
                            className="google-icon6"
                            loading="lazy"
                            alt=""
                            src="/google-1@2x.png"
                          />
                        </div>
                        <div className="copyright-maiatech-2016-202-wrapper">
                          <div className="copyright-maiatech5">
                            {" "}
                            Copyright © MaiATech 2016. 2020.
                          </div>
                        </div>
                      </div>
                      <div className="home-page-header">
                        <div className="copyright-maiatech6">
                          Copyright © MaiATech 2016
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="trang-ch-gii-container2">
                <p className="trang-ch2">Trang chủ</p>
                <p className="gii-thiu6">Giới thiệu</p>
                <p className="dch-v5">Dịch vụ</p>
                <p className="d-n5">Dự án</p>
                <p className="i-ng5">Đội ngũ</p>
                <p className="blank-line45">&nbsp;</p>
              </div>
            </div>
          </div>
          <div className="sub-menu" />
        </footer>
      </section>
      <div className="active-link">
        <div className="inactive-link">
          <img
            className="inactive-link-child"
            loading="lazy"
            alt=""
            src="/group-115@2x.png"
          />
          <div className="copyright-maiatech-2020-frame">
            <div className="copyright-maiatech7">
              {" "}
              Copyright © MaiATech 2020.
            </div>
          </div>
        </div>
      </div>
      <div className="gii-thiu-child1" />
    </div>
  );
};

export default GiiThiu;
