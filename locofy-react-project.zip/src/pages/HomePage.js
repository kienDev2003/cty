import { useCallback } from "react";
import { useNavigate } from "react-router-dom";
import "./HomePage.css";

const HomePage = () => {
  const navigate = useNavigate();

  const onGIITHIUTextClick = useCallback(() => {
    navigate("/gii-thiu");
  }, [navigate]);

  const onLINHTextClick = useCallback(() => {
    navigate("/");
  }, [navigate]);

  return (
    <div className="home-page">
      <img className="tucozi-icon1" alt="" />
      <div className="tucozi1" />
      <section className="frame-parent4">
        <img
          className="frame-child4"
          loading="lazy"
          alt=""
          src="/group-19.svg"
        />
        <h1 className="maiatech2">MAIATECH</h1>
        <img className="mask-group-icon3" alt="" src="/mask-group@2x.png" />
        <img className="mask-group-icon4" alt="" src="/mask-group-11@2x.png" />
        <h1 className="who">WHO</h1>
        <h1 className="we-are">WE ARE</h1>
        <img className="line-icon" loading="lazy" alt="" src="/line-3.svg" />
        <img className="frame-child5" loading="lazy" alt="" src="/line-4.svg" />
      </section>
      <div className="home-page-inner">
        <header className="frame-header">
          <div className="frame-parent5">
            <div className="frame-wrapper4">
              <div className="maiatech-container">
                <img className="maiatech-icon4" alt="" src="/maiatech-2.svg" />
                <div className="maiatech-parent1">
                  <img className="maiatech-icon5" alt="" src="/maiatech.svg" />
                  <img className="maiatech-icon6" alt="" src="/maiatech.svg" />
                </div>
              </div>
            </div>
            <nav className="gii-thiu-group">
              <div className="gii-thiu2" onClick={onGIITHIUTextClick}>
                GIỚI THIỆU
              </div>
              <div className="dch-v2">DỊCH VỤ</div>
              <div className="d-n2">DỰ ÁN</div>
              <div className="i-ng2">ĐỘI NGŨ</div>
              <div className="lin-h2" onClick={onLINHTextClick}>
                LIÊN HỆ
              </div>
            </nav>
          </div>
          <div className="nhiu-n-lc-mt-nim-tin-container">
            <div className="nhiu-n-lc3">nhiều nỗ lực - một niềm tin</div>
          </div>
        </header>
      </div>
      <section className="mask-group-group">
        <img className="mask-group-icon5" alt="" src="/mask-group-2@2x.png" />
        <div className="hotline-0936-468-container2">
          <p className="hotline3">
            <span className="hotline4">
              <b>hotline</b>
            </span>
          </p>
          <p className="p1">
            <span className="span2">
              <span className="span3">
                0936 468 486 - 0979 723 816 0936 468 688 - 0912 922 530
              </span>
            </span>
          </p>
          <p className="blank-line13">
            <span className="blank-line14">
              <span className="blank-line15">&nbsp;</span>
            </span>
          </p>
          <p className="email4">
            <span className="email5">
              <b>email</b>
            </span>
          </p>
          <p className="contactmaiatechcomvn">
            <span className="contactmaiatechcomvn1">
              <span>contact@maiatech.com.vn</span>
            </span>
          </p>
          <p className="blank-line16">
            <span className="blank-line17">
              <b>&nbsp;</b>
            </span>
          </p>
          <p className="address3">
            <span className="address4">
              <b>address</b>
            </span>
          </p>
          <p className="s-26-ng-cu-vit-1-th-tr2">
            <span className="s-26-ng-cu-vit-1-th-tr3">
              <span className="s-26-ng1">
                Số 26 đường Cửu Việt 1, thị trấn Trâu Quỳ, huyện Gia Lâm, Hà Nội
              </span>
            </span>
          </p>
          <p className="blank-line18">
            <span className="blank-line19">
              <span className="blank-line20">&nbsp;</span>
            </span>
          </p>
          <p className="blank-line21">
            <span className="blank-line22">
              <span className="blank-line23">&nbsp;</span>
            </span>
          </p>
        </div>
      </section>
      <img className="mask-group-icon6" alt="" src="/mask-group-3@2x.png" />
      <section className="frame-parent6">
        <div className="frame-wrapper5">
          <div className="frame-parent7">
            <div className="rectangle-frame">
              <div className="frame-child6" />
            </div>
            <div className="group">
              <div className="div1">1</div>
              <div className="frame-wrapper6">
                <div className="frame-parent8">
                  <div className="button-button-normal-group">
                    <div className="button-button-normal4">
                      <div className="rectangle4" />
                      <div className="contact-us2">CONTACT US</div>
                    </div>
                    <button className="button-button-normal5">
                      <div className="rectangle5" />
                      <b className="follow-us1">FOLLOW US</b>
                    </button>
                  </div>
                  <div className="facebook-group">
                    <img
                      className="facebook-icon2"
                      alt=""
                      src="/facebook1.svg"
                    />
                    <img className="twitter-icon2" alt="" src="/twitter1.svg" />
                    <img className="google-icon2" alt="" src="/google@2x.png" />
                  </div>
                  <div className="nhiu-n-lc-group">
                    <h1 className="nhiu-n-lc4">nhiều nỗ lực</h1>
                    <h1 className="nim-tin1">niềm tin</h1>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="frame-parent9">
          <div className="mask-group-container">
            <img
              className="mask-group-icon7"
              alt=""
              src="/mask-group-4@2x.png"
            />
            <div className="frame-child7" />
            <div className="frame-child8" />
          </div>
          <div className="frame-parent10">
            <div className="ellipse-group">
              <div className="frame-child9" />
              <img className="frame-child10" alt="" src="/line-2.svg" />
            </div>
            <div className="rectangle-parent1">
              <div className="frame-child11" />
              <div className="cng-ty-tnhh-cng-ngh-maia-ma-parent">
                <div className="cng-ty-tnhh-container">
                  <span>
                    <p className="cng-ty-tnhh-cng-ngh-maia">
                      <b>Công ty TNHH Công nghệ MaiA</b>
                    </p>
                    <p className="maia-technology-coltd-maiate">
                      <b>MaiA Technology Co.Ltd (MaiATech)</b>
                    </p>
                    <p className="blank-line24">
                      <b>&nbsp;</b>
                    </p>
                    <p className="cng-ty-maiatech">
                      Công ty MaiaTech được thành lập vào ngày
                    </p>
                    <p className="nm-2015">năm 2015 .........</p>
                    <p className="cng-ty-tnhh">
                      Công ty TNHH Công nghệ Mai A, chuyên cung cấp giải pháp
                      phân tích thiết kế hệ thống và xây dựng phần mềm ứng dụng
                      theo yêu cầu. Bao gồm ứng dụng mobile, ứng dụng web, ứng
                      dụng desktop. Sau một thời gian lắng nghe yêu cầu từ phía
                      khách hàng, với sự trao đổi, tư vấn của Mai A, hai bên sẽ
                      đề ra các yêu cầu và tiến độ thực hiện công việc. Cho đến
                      nay, các sản phẩm của công ty đều đạt tiến độ và chất
                      lượng đề ra.
                    </p>
                  </span>
                </div>
                <button className="button-button-normal6">
                  <div className="rectangle6" />
                  <div className="read-more">Read more</div>
                </button>
              </div>
              <div className="frame-wrapper7">
                <div className="mask-group-parent1">
                  <img
                    className="mask-group-icon8"
                    alt=""
                    src="/mask-group-5@2x.png"
                  />
                  <div className="line-parent">
                    <img className="frame-child12" alt="" src="/line-1.svg" />
                    <img
                      className="mask-group-icon9"
                      alt=""
                      src="/mask-group-6@2x.png"
                    />
                  </div>
                  <img
                    className="mask-group-icon10"
                    alt=""
                    src="/mask-group-7@2x.png"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <div className="ellipse-container">
        <div className="frame-child13" />
        <img className="frame-child14" alt="" src="/line-2-1.svg" />
      </div>
      <section className="home-page-child">
        <div className="frame-parent11">
          <div className="frame-wrapper8">
            <div className="frame-parent12">
              <div className="what-we-do-wrapper">
                <h1 className="what-we-do">what we do</h1>
              </div>
              <div className="vi-quy-trnh">
                Với quy trình làm việc khoa học từng bước một, maiatech sẽ cùng
                bạn giải quyết tất cả các vấn để với phương châm “Your Problem,
                Our Solution”
              </div>
            </div>
          </div>
          <div className="frame-parent13">
            <div className="frame-wrapper9">
              <div className="frame-parent14">
                <div className="brain-1-parent">
                  <img
                    className="brain-1-icon"
                    loading="lazy"
                    alt=""
                    src="/brain-1.svg"
                  />
                  <img
                    className="user-1-icon"
                    loading="lazy"
                    alt=""
                    src="/user-1.svg"
                  />
                  <img
                    className="vector-1-icon"
                    loading="lazy"
                    alt=""
                    src="/vector-1.svg"
                  />
                  <img
                    className="development-1-icon"
                    alt=""
                    src="/development-1.svg"
                  />
                  <img
                    className="new-product-1-icon"
                    alt=""
                    src="/newproduct-1.svg"
                  />
                </div>
                <div className="frame-wrapper10">
                  <div className="ellipse-parent1">
                    <div className="frame-child15" />
                    <img
                      className="frame-child16"
                      alt=""
                      src="/group-101.svg"
                    />
                    <img
                      className="frame-child17"
                      alt=""
                      src="/group-101.svg"
                    />
                    <div className="frame-parent15">
                      <img
                        className="frame-child18"
                        alt=""
                        src="/group-103.svg"
                      />
                      <img
                        className="frame-child19"
                        alt=""
                        src="/line-2-2.svg"
                      />
                    </div>
                    <img
                      className="frame-child20"
                      alt=""
                      src="/group-101.svg"
                    />
                  </div>
                </div>
              </div>
            </div>
            <div className="frame-parent16">
              <div className="frame-parent17">
                <div className="ideal-wrapper">
                  <b className="ideal">ideal</b>
                </div>
                <div className="lorem-ipsum-is">{`Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever `}</div>
              </div>
              <div className="frame-parent18">
                <div className="strategy-wrapper">
                  <b className="strategy">strategy</b>
                </div>
                <div className="lorem-ipsum-is1">{`Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever `}</div>
              </div>
              <div className="frame-parent19">
                <div className="design-wrapper">
                  <b className="design">design</b>
                </div>
                <div className="lorem-ipsum-is2">{`Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever `}</div>
              </div>
              <div className="frame-parent20">
                <div className="development-wrapper">
                  <b className="development">development</b>
                </div>
                <div className="lorem-ipsum-is3">{`Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever `}</div>
              </div>
              <div className="frame-parent21">
                <div className="product-wrapper">
                  <b className="product">product</b>
                </div>
                <div className="lorem-ipsum-is4">{`Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever `}</div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <section className="frame-parent22">
        <img
          className="frame-child21"
          loading="lazy"
          alt=""
          src="/group-1151@2x.png"
        />
        <div className="frame-wrapper11">
          <div className="frame-parent23">
            <div className="frame-wrapper12">
              <div className="frame-parent24">
                <div className="our-parent">
                  <h1 className="our">OUR</h1>
                  <div className="services-wrapper">
                    <h1 className="services">SERVICES</h1>
                  </div>
                </div>
                <div className="vi-nh-hng-chin-lc-tron-wrapper">
                  <div className="vi-nh-hng">
                    Với định hướng chiến lược trong vòng 10 năm, MaiATech phấn
                    đấu trở thành công ty chuyên nghiệp hàng đầu Việt Nam trong
                    các lĩnh vực cung cấp ứng dụng phần mềm trên nền tảng
                    Internet. Góp phần tăng năng suất, hiệu quả cho nền kinh tế,
                    hướng tới phát triển có chiều sâu, MaiATech đã và đang tập
                    trung năng lực chuyên môn và nguồn lực tài chính cho các
                    lĩnh vực hoạt động sau
                  </div>
                </div>
                <div className="data-aggregator2">
                  <div className="branch-condition">
                    <div className="input-filter2">
                      <div className="output-merge">
                        <div className="loop-control1">
                          <div className="error-handler1">
                            <img
                              className="outline-icon"
                              loading="lazy"
                              alt=""
                              src="/outline.svg"
                            />
                          </div>
                          <b className="phn-mm-qun">Phần mềm quản lý</b>
                        </div>
                      </div>
                      <div className="phn-mm-qun-container">
                        <span>
                          <p className="phn-mm-qun1">
                            + Phần mềm Quản lý nhân sự - HRM
                          </p>
                          <p className="phn-mm-qun2">
                            + Phần mềm Quản lý công văn – Doc
                          </p>
                          <p className="phn-mm-qun3">
                            + Phần mềm Quản lý khách hàng – Customer
                          </p>
                          <p className="phn-mm-k">
                            + Phần mềm Kế toán - Accounting
                          </p>
                        </span>
                      </div>
                    </div>
                    <div className="comparison-operator">
                      <div className="arithmetic-operation">
                        <div className="logical-operation">
                          <div className="sequence-operator">
                            <img
                              className="settings-1-icon"
                              loading="lazy"
                              alt=""
                              src="/settings-1.svg"
                            />
                          </div>
                          <b className="t-vn-thit-container">
                            <p className="t-vn-thit">{`Tư vấn, thiết kế website, `}</p>
                            <p className="gii-php-tmt">giải pháp TMĐT</p>
                          </b>
                        </div>
                        <div className="while-loop">
                          <div className="t-vn-thit-container1">
                            <span>
                              <p className="t-vn-thit1">
                                + Tư vấn thiết kế website giới thiệu doanh
                                nghiệp
                              </p>
                              <p className="t-vn-thit2">
                                + Tư vấn thiết kế website bán hàng
                              </p>
                              <p className="t-vn-thit3">
                                + Tư vấn thiết kế và cung cấp giải pháp TMĐT
                              </p>
                              <p className="h-tr-k">
                                + Hỗ trợ kỹ thuật và cung cấp giải pháp xử lý sự
                                cố
                              </p>
                            </span>
                          </div>
                        </div>
                      </div>
                      <div className="switch-case">
                        <div className="try-catch-block">
                          <img
                            className="database-server-icon"
                            loading="lazy"
                            alt=""
                            src="/database-server.svg"
                          />
                        </div>
                        <div className="variable-declaration">
                          <b className="domain-hosting-vps-container">
                            <p className="domain-hosting">{`Domain, hosting, `}</p>
                            <p className="vps-email">VPS, email</p>
                          </b>
                        </div>
                        <div className="ng-k-gia-container">
                          <span>
                            <p className="ng-k-gia">
                              + Đăng ký, gia hạn tên miền (domain)
                            </p>
                            <p className="cho-thu-hosting">
                              + Cho thuê hosting
                            </p>
                            <p className="cho-thu-my">
                              + Cho thuê máy chủ ảo (VPS)
                            </p>
                            <p className="cho-thu-email">
                              + Cho thuê email server
                            </p>
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="method-call">
              <img
                className="mask-group-icon11"
                alt=""
                src="/mask-group-8@2x.png"
              />
              <img
                className="method-call-child"
                alt=""
                src="/group-172@2x.png"
              />
            </div>
          </div>
        </div>
      </section>
      <section className="property-access">
        <div className="array-access">
          <div className="index-calculation" />
        </div>
        <div className="string-manipulation">
          <div className="function-invoker">
            <div className="expression-tree">
              <div className="control-flow-graph">
                <h1 className="application">APPLICATION</h1>
                <h1 className="development1">DEVELOPMENT</h1>
              </div>
              <div className="pht-trin-ng-container">
                <span className="pht-trin-ng-container1">
                  <p className="pht-trin-ng">
                    Phát triển ứng dụng, chương trình đa nền tảng
                  </p>
                </span>
              </div>
            </div>
            <div className="global-variable">
              <div className="function-parameter">
                <div className="return-value">
                  <b className="desktop-development">desktop development</b>
                  <div className="error-message">
                    <div className="lorem-ipsum-is5">{`Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever `}</div>
                  </div>
                  <div className="code-editor">
                    <div className="code-runner" />
                    <img
                      className="group-icon1"
                      loading="lazy"
                      alt=""
                      src="/group.svg"
                    />
                  </div>
                </div>
              </div>
              <div className="import-declaration">
                <div className="annotation">
                  <div className="comment">
                    <img
                      className="library-reference-icon"
                      alt=""
                      src="/library-reference.svg"
                    />
                    <div className="to-cc-ng">
                      tạo các ứng dụng web để chạy trên môi trường trình duyệt
                      web.
                    </div>
                  </div>
                </div>
                <b className="web-development">web development</b>
                <div className="build-automation">
                  <div className="data-aggregator3" />
                  <img
                    className="coding-1-icon"
                    loading="lazy"
                    alt=""
                    src="/coding-1.svg"
                  />
                </div>
              </div>
              <div className="function-parameter1">
                <div className="mobile-development-parent">
                  <b className="mobile-development">mobile development</b>
                  <div className="tao-ra-phn-mm-ng-dng-mobil-wrapper">
                    <div className="tao-ra-phn">{`tao ra phần mềm ứng dụng mobile được người dùng mua thông qua các “cửa hàng ứng dụng” như Google Play, App Store, CH Play,… `}</div>
                  </div>
                  <div className="ellipse-parent2">
                    <div className="frame-child22" />
                    <img
                      className="frame-child23"
                      loading="lazy"
                      alt=""
                      src="/group-149.svg"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="rectangle-parent2">
            <div className="frame-child24" />
            <div className="output-processor">
              <h1 className="nhn-bo-gi">{`Nhận báo giá & tư vấn trực tiếp`}</h1>
            </div>
            <div className="frame-parent25">
              <button className="group-button">
                <div className="frame-child25" />
                <div className="tn-ca-bn1">Tên của bạn *</div>
              </button>
              <div className="rectangle-parent3">
                <div className="frame-child26" />
                <div className="email6">Email *</div>
              </div>
              <button className="rectangle-parent4">
                <div className="frame-child27" />
                <div className="cng-ty">Công ty *</div>
              </button>
              <button className="rectangle-parent5">
                <div className="frame-child28" />
                <div className="nhn-bo-gi1">Nhận báo giá</div>
              </button>
            </div>
          </div>
        </div>
      </section>
      <section className="image-processor1">
        <img
          className="geometry-transformer-icon"
          alt=""
          src="/geometry-transformer.svg"
        />
        <div className="value-comparator">
          <div className="data-merger">
            <div className="flag-signaler">
              <div className="condition-splitter">
                <img
                  className="condition-splitter-child"
                  loading="lazy"
                  alt=""
                  src="/group-158@2x.png"
                />
                <div className="chuyn-nhu-cu">
                  Chuyển nhu cầu của người dùng hoặc mục tiêu tiếp thị thành một
                  sản phẩm phần mềm (sofware)
                </div>
              </div>
            </div>
            <div className="label-organizer">
              <div className="data-sorter">
                <h1 className="sofware">SOFWARE</h1>
              </div>
              <h1 className="development2">DEVELOPMENT</h1>
            </div>
          </div>
        </div>
      </section>
      <section className="color-picker">
        <div className="value-transformer">
          <div className="geometry-combiner">
            <div className="input-validator">
              <div className="image-overlay-parent">
                <div className="image-overlay">
                  <div className="lorem-ipsum-is6">{`Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever `}</div>
                </div>
                <b className="fixed-project">fixed project</b>
                <div className="geometry-tweaker">
                  <div className="value-comparer" />
                  <img
                    className="bug-1-icon"
                    loading="lazy"
                    alt=""
                    src="/bug-1.svg"
                  />
                </div>
              </div>
            </div>
            <div className="label-merger">
              <div className="data-sifter">
                <div className="lorem-ipsum-is7">{`Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever `}</div>
              </div>
              <b className="managed-team">managed team</b>
              <div className="value-booster">
                <div className="shape-fusion" />
                <img
                  className="network-1-icon"
                  loading="lazy"
                  alt=""
                  src="/network-1.svg"
                />
              </div>
            </div>
            <div className="input-validator1">
              <div className="managed-services-parent">
                <b className="managed-services">managed services</b>
                <div className="dch-v-c">
                  Dịch vụ được quản lý là thực hành thuê ngoài trên cơ sở chủ
                  động các quy trình và chức năng nhất định nhằm cải thiện hoạt
                  động và cắt giảm chi phí
                </div>
                <div className="ellipse-parent3">
                  <div className="frame-child29" />
                  <img
                    className="process-1-icon"
                    loading="lazy"
                    alt=""
                    src="/process-1.svg"
                  />
                </div>
              </div>
            </div>
          </div>
          <div className="label-cutter">
            <div className="image-splitter">
              <div className="value-organizer-parent">
                <div className="value-organizer">
                  <div className="shape-sorter">
                    <div className="image-merger">
                      <div className="label-assembler" />
                    </div>
                    <h1 className="meet-our-team">meet our team</h1>
                  </div>
                </div>
                <div className="mt-s-thnh">
                  Một số thành viên chủ chốt trong đội ngũ
                </div>
              </div>
              <div className="value-matcher">
                <div className="frame-parent26">
                  <div className="frame-wrapper13">
                    <div className="rectangle-parent6">
                      <div className="frame-child30" />
                      <img
                        className="mask-group-icon12"
                        alt=""
                        src="/mask-group-9@2x.png"
                      />
                      <div className="frame-wrapper14">
                        <div className="frame-parent27">
                          <div className="ks-cntt-l-sn-tng-wrapper">
                            <b className="ks-cntt-l">KS CNTT Lê Sơn Tùng</b>
                          </div>
                          <div className="pg-pt-khch">
                            PGĐ PT Khách hàng dự án
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="wrapper-group-122-parent">
                    <div className="wrapper-group-122">
                      <img
                        className="wrapper-group-122-child"
                        loading="lazy"
                        alt=""
                        src="/group-122@2x.png"
                      />
                    </div>
                    <b className="ths-cntt-l">ThS CNTT Lê Doãn Phước</b>
                    <div className="gim-c-wrapper">
                      <div className="gim-c">Giám đốc</div>
                    </div>
                  </div>
                  <div className="frame-wrapper15">
                    <div className="rectangle-parent7">
                      <div className="frame-child31" />
                      <img
                        className="mask-group-icon13"
                        alt=""
                        src="/mask-group-10@2x.png"
                      />
                      <div className="frame-wrapper16">
                        <div className="frame-parent28">
                          <div className="ths-v-hu-dng-wrapper">
                            <b className="ths-v-hu">ThS Vũ Hữu Dũng</b>
                          </div>
                          <div className="trng-phng-h">
                            Trưởng phòng Hệ thống thông tin
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="frame-parent29">
            <div className="frame-wrapper17">
              <div className="rectangle-parent8">
                <div className="frame-child32" />
                <div className="frame-child33" />
                <div className="frame-child34" />
              </div>
            </div>
            <div className="frame-parent30">
              <div className="our-group">
                <h1 className="our1">OUR</h1>
                <div className="goals-wrapper">
                  <h1 className="goals">GOALS</h1>
                </div>
              </div>
              <div className="mt-s-sn-phm-pht-trin-ri-wrapper">
                <div className="mt-s-sn">
                  Một số sản phẩm phát triển riêng cho từng đơn vị mà các thành
                  viên của công ty đã tham gia.
                </div>
              </div>
            </div>
            <div className="frame-wrapper18">
              <div className="rectangle-parent9">
                <div className="frame-child35" />
                <img
                  className="frame-child36"
                  loading="lazy"
                  alt=""
                  src="/line-7.svg"
                />
                <div className="frame-wrapper19">
                  <div className="cng-thng-tin-in-t-b-giao-parent">
                    <b className="cng-thng-tin">
                      Cổng thông tin điện tử Bộ Giao thông vận tải
                    </b>
                    <div className="what-is-lorem-ipsum-lorem-ips-wrapper">
                      <div className="what-is-lorem-container">
                        <span>
                          <p className="what-is-lorem">What is Lorem Ipsum?</p>
                          <p className="lorem-ipsum-is8">
                            Lorem Ipsum is simply dummy text of the printing and
                            typesetting industry. Lorem Ipsum has been the
                            industry's standard dummy text ever since the 1500s,
                            when an unknown printer took a galley of type and
                            scrambled it to make a type specimen book. It has
                            survived not only five centuries, but also the leap
                            into electronic typesetting, remaining essentially
                            unchanged. It was popularised in the 1960s with the
                            release of Letraset sheets containing Lorem Ipsum
                            passages, and more recently with desktop publishing
                            software like Aldus PageMaker including versions of
                            Lorem Ipsum.
                          </p>
                          <p className="blank-line25">&nbsp;</p>
                          <p className="why-do-we">Why do we use it?</p>
                          <p className="it-is-a">
                            It is a long established fact that a reader will be
                            distracted by the readable content of a page when
                            looking at its layout. The point of using Lorem
                            Ipsum is that it has a more-or-less normal
                            distribution of letters, as opposed to using
                            'Content here, content here', making it look like
                            readable English. Many desktop publishing packages
                            and web page editors now use Lorem Ipsum as their
                            default model text, and a search for 'lorem ipsum'
                            will uncover many web sites still in their infancy.
                            Various versions have evolved over the years, so
                          </p>
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
                <img
                  className="mask-group-icon14"
                  alt=""
                  src="/mask-group-111@2x.png"
                />
              </div>
            </div>
            <div className="frame-wrapper20">
              <div className="rectangle-parent10">
                <div className="frame-child37" />
                <div className="frame-child38" />
                <div className="frame-child39" />
                <div className="frame-child40" />
                <div className="frame-child41" />
                <div className="frame-child42" />
                <div className="frame-child43" />
                <div className="frame-child44" />
                <div className="frame-child45" />
              </div>
            </div>
          </div>
        </div>
      </section>
      <section className="ellipse-parent4">
        <div className="frame-child46" />
        <div className="tools-indicator-icon-container">
          <img
            className="tools-indicator-icon1"
            loading="lazy"
            alt=""
            src="/-tools--indicator--icon.svg"
          />
        </div>
      </section>
      <section className="home-page-inner1">
        <div className="rectangle-parent11">
          <div className="frame-child47" />
          <div className="frame-wrapper21">
            <div className="chng-ti-cam-kt-mang-ti-cho-parent">
              <h1 className="chng-ti-cam-container1">
                <p className="chng-ti-cam1">{`Chúng tôi cam kết mang tới cho `}</p>
                <p className="khch-hng-nhng1">
                  Khách hàng những giải pháp chuyên nghiệp nhất !
                </p>
              </h1>
              <div className="frame-wrapper22">
                <div className="your-problem-group">
                  <h1 className="your-problem1">Your Problem.</h1>
                  <div className="our-solution-container">
                    <h1 className="our-solution1">Our Solution.</h1>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="button-button-normal-parent1">
            <button className="button-button-normal7">
              <div className="rectangle7" />
              <div className="contact-us3">Contact Us</div>
            </button>
            <div className="frame-wrapper23">
              <div className="rectangle-parent12">
                <div className="frame-child48" />
                <div className="rectangle-parent13">
                  <div className="frame-child49" />
                  <div className="frame-child50" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <footer className="frame-footer">
        <div className="rectangle-wrapper1">
          <div className="frame-child51" />
        </div>
        <div className="frame-wrapper24">
          <div className="frame-parent31">
            <div className="frame-wrapper25">
              <div className="frame-parent32">
                <div className="frame-parent33">
                  <div className="frame-wrapper26">
                    <div className="maiatech-parent2">
                      <img
                        className="maiatech-icon7"
                        alt=""
                        src="/maiatech.svg"
                      />
                      <img
                        className="maiatech-icon8"
                        alt=""
                        src="/maiatech.svg"
                      />
                    </div>
                  </div>
                  <div className="nhiu-n-lc-mt-nim-tin-frame">
                    <div className="nhiu-n-lc5">
                      nhiều nỗ lực - một niềm tin
                    </div>
                  </div>
                </div>
                <div className="frame-wrapper27">
                  <div className="facebook-container">
                    <img
                      className="facebook-icon3"
                      alt=""
                      src="/facebook-11.svg"
                    />
                    <img
                      className="twitter-icon3"
                      alt=""
                      src="/twitter-11.svg"
                    />
                    <img className="google-icon3" alt="" src="/google@2x.png" />
                  </div>
                </div>
              </div>
            </div>
            <div className="copyright-maiatech3">Copyright © MaiATech 2016</div>
          </div>
        </div>
        <div className="trang-ch-gii-thiu-dch-v-d-wrapper">
          <div className="trang-ch-gii-container1">
            <p className="trang-ch1">Trang chủ</p>
            <p className="gii-thiu3">Giới thiệu</p>
            <p className="dch-v3">Dịch vụ</p>
            <p className="d-n3">Dự án</p>
            <p className="i-ng3">Đội ngũ</p>
            <p className="blank-line26">&nbsp;</p>
          </div>
        </div>
        <div className="frame-child52" />
      </footer>
      <div className="home-page-inner2">
        <div className="frame-parent34">
          <img className="frame-child53" alt="" src="/group-115@2x.png" />
          <div className="copyright-maiatech-2020-container">
            <div className="copyright-maiatech4">
              {" "}
              Copyright © MaiATech 2020.
            </div>
          </div>
        </div>
      </div>
      <div className="home-page-item" />
      <div className="home-page-child1" />
      <div className="home-page-child2" />
    </div>
  );
};

export default HomePage;
