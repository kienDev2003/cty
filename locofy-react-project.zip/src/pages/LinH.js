import { useCallback } from "react";
import { useNavigate } from "react-router-dom";
import "./LinH.css";

const LinH = () => {
  const navigate = useNavigate();

  const onMAIATECH1Click = useCallback(() => {
    navigate("/home-page");
  }, [navigate]);

  const onGIITHIUTextClick = useCallback(() => {
    navigate("/gii-thiu");
  }, [navigate]);

  const onButtonButtonNormal1Click = useCallback(() => {
    // Please sync "Liên hệ click submit" to the project
  }, []);

  return (
    <div className="lin-h">
      <img className="tucozi-icon" alt="" />
      <div className="tucozi" />
      <section className="function-tree">
        <div className="input-processor">
          <div className="decision-maker" />
          <img
            className="output-generator-icon"
            alt=""
            src="/output-generator.svg"
          />
        </div>
        <img
          className="function-tree-child"
          loading="lazy"
          alt=""
          src="/group-19.svg"
        />
        <h1 className="maiatech">MAIATECH</h1>
        <img className="mask-group-icon" alt="" src="/mask-group@2x.png" />
        <img
          className="function-tree-item"
          loading="lazy"
          alt=""
          src="/line-3.svg"
        />
        <img
          className="function-tree-inner"
          loading="lazy"
          alt=""
          src="/line-4.svg"
        />
      </section>
      <div className="data-flow-wrapper">
        <header className="data-flow">
          <div className="subroutine-parent">
            <div className="subroutine">
              <div className="maiatech-parent">
                <img className="maiatech-icon" alt="" src="/maiatech.svg" />
                <div className="maiatech-group">
                  <img className="maiatech-icon1" alt="" src="/maiatech.svg" />
                  <img
                    className="maiatech-icon2"
                    alt=""
                    src="/maiatech-2.svg"
                    onClick={onMAIATECH1Click}
                  />
                </div>
              </div>
            </div>
            <nav className="gii-thiu-parent">
              <div className="gii-thiu" onClick={onGIITHIUTextClick}>
                GIỚI THIỆU
              </div>
              <div className="dch-v">DỊCH VỤ</div>
              <div className="d-n">DỰ ÁN</div>
              <div className="i-ng">ĐỘI NGŨ</div>
              <div className="lin-h1">LIÊN HỆ</div>
            </nav>
          </div>
          <div className="nhiu-n-lc-mt-nim-tin-wrapper">
            <div className="nhiu-n-lc">nhiều nỗ lực - một niềm tin</div>
          </div>
        </header>
      </div>
      <section className="mask-group-parent">
        <img className="mask-group-icon1" alt="" src="/mask-group-1@2x.png" />
        <div className="hotline-0936-468-container">
          <p className="hotline">
            <span className="hotline1">
              <b className="hotline2">hotline</b>
            </span>
          </p>
          <p className="p">
            <span className="span">
              <span className="span1">
                0936 468 486 - 0979 723 816 0936 468 688 - 0912 922 530
              </span>
            </span>
          </p>
          <p className="blank-line">
            <span className="blank-line1">
              <span className="blank-line2">&nbsp;</span>
            </span>
          </p>
          <p className="email">
            <span className="email1">
              <b className="email2">email</b>
            </span>
          </p>
          <p className="infodolphinhomegmailcom">
            <a
              className="infodolphinhomegmailcom1"
              href="mailto:contact@maiatech.com.vn"
              target="_blank"
            >
              <span className="infodolphinhomegmailcom2">
                <span className="infodolphinhomegmailcom3">
                  infodolphinhome@gmail.com
                </span>
              </span>
            </a>
          </p>
          <p className="blank-line3">
            <span className="blank-line4">
              <b className="blank-line5">&nbsp;</b>
            </span>
          </p>
          <p className="address">
            <span className="address1">
              <b className="address2">address</b>
            </span>
          </p>
          <p className="s-26-ng-cu-vit-1-th-tr">
            <span className="s-26-ng-cu-vit-1-th-tr1">
              <span className="s-26-ng">
                Số 26 đường Cửu Việt 1, thị trấn Trâu Quỳ, huyện Gia Lâm, Hà Nội
              </span>
            </span>
          </p>
          <p className="blank-line6">
            <span className="blank-line7">
              <span className="blank-line8">&nbsp;</span>
            </span>
          </p>
          <p className="blank-line9">
            <span className="blank-line10">
              <span className="blank-line11">&nbsp;</span>
            </span>
          </p>
        </div>
      </section>
      <img className="mask-group-icon2" alt="" src="/mask-group@2x.png" />
      <section className="lin-h-inner">
        <div className="frame-parent">
          <div className="rectangle-wrapper">
            <div className="frame-child" />
          </div>
          <div className="parent">
            <div className="div">1</div>
            <div className="frame-wrapper">
              <div className="frame-group">
                <div className="button-button-normal-parent">
                  <div className="button-button-normal">
                    <div className="rectangle" />
                    <div className="contact-us">CONTACT US</div>
                  </div>
                  <button className="button-button-normal1">
                    <div className="rectangle1" />
                    <b className="follow-us">FOLLOW US</b>
                  </button>
                </div>
                <div className="facebook-parent">
                  <img
                    className="facebook-icon"
                    loading="lazy"
                    alt=""
                    src="/facebook.svg"
                  />
                  <img
                    className="twitter-icon"
                    loading="lazy"
                    alt=""
                    src="/twitter.svg"
                  />
                  <img
                    className="google-icon"
                    loading="lazy"
                    alt=""
                    src="/google@2x.png"
                  />
                </div>
                <div className="nhiu-n-lc-parent">
                  <h1 className="nhiu-n-lc1">nhiều nỗ lực</h1>
                  <h1 className="nim-tin">niềm tin</h1>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <section className="frame-container">
        <div className="rectangle-container">
          <div className="frame-item" />
        </div>
        <div className="ellipse-wrapper">
          <div className="frame-inner" />
        </div>
        <div className="rectangle-parent">
          <div className="rectangle-div" />
          <div className="tn-ca-bn-parent">
            <b className="tn-ca-bn">Tên của bạn *</b>
            <div className="data-aggregator-wrapper">
              <div className="data-aggregator" />
            </div>
          </div>
          <div className="input-filter">
            <div className="output-combiner">
              <b className="email3">Email *</b>
              <div className="output-combiner-inner">
                <div className="line-div" />
              </div>
            </div>
            <div className="frame-div">
              <div className="cng-ty-t-chc-parent">
                <b className="cng-ty-t">Công ty/ Tổ chức *</b>
                <div className="decision-tree">
                  <div className="decision-tree-child" />
                </div>
              </div>
              <div className="message-parent">
                <b className="message">Message</b>
                <textarea className="rectangle-textarea" rows={10} cols={28} />
              </div>
            </div>
            <div className="button-button-normal-wrapper">
              <button
                className="button-button-normal2"
                onClick={onButtonButtonNormal1Click}
              >
                <div className="rectangle2" />
                <div className="submit">Submit</div>
              </button>
            </div>
          </div>
        </div>
      </section>
      <section className="frame-section">
        <div className="frame-wrapper1">
          <div className="frame-parent1">
            <div className="message-for-parent">
              <h1 className="message-for">Message for</h1>
              <div className="maiatech-wrapper">
                <h1 className="maiatech1"> Maiatech</h1>
              </div>
            </div>
            <div className="hotline-0936-468-486-wrapper">
              <div className="hotline-0936-468-container1">
                <b>{`hotline: `}</b>
                <span>0936 468 486</span>
              </div>
            </div>
          </div>
        </div>
        <div className="tools-indicator-icon-wrapper">
          <img
            className="tools-indicator-icon"
            loading="lazy"
            alt=""
            src="/-tools--indicator--icon.svg"
          />
        </div>
        <div className="frame-wrapper2">
          <div className="rectangle-group">
            <div className="frame-child1" />
            <div className="chng-ti-cam-kt-mang-ti-cho-wrapper">
              <h1 className="chng-ti-cam-container">
                <p className="chng-ti-cam">{`Chúng tôi cam kết mang tới cho `}</p>
                <p className="khch-hng-nhng">
                  Khách hàng những giải pháp chuyên nghiệp nhất !
                </p>
              </h1>
            </div>
            <div className="frame-wrapper3">
              <div className="your-problem-parent">
                <h1 className="your-problem">Your Problem.</h1>
                <div className="our-solution-wrapper">
                  <h1 className="our-solution">Our Solution.</h1>
                </div>
              </div>
            </div>
            <div className="frame-parent2">
              <div className="button-button-normal-container">
                <button className="button-button-normal3">
                  <div className="rectangle3" />
                  <div className="contact-us1">Contact Us</div>
                </button>
              </div>
              <div className="group-div">
                <div className="frame-child2" />
                <div className="stack-overflow-error-parent">
                  <div className="stack-overflow-error" />
                  <div className="stack-overflow-error1" />
                </div>
              </div>
            </div>
          </div>
        </div>
        <footer className="heap-overflow-error">
          <div className="null-pointer-exception">
            <div className="index-out-of-bounds-error" />
          </div>
          <div className="division-by-zero-error">
            <div className="array-index-out-of-bounds-erro">
              <div className="illegal-argument-exception">
                <div className="data-aggregator1">
                  <div className="input-filter1">
                    <img
                      className="maiatech-icon3"
                      loading="lazy"
                      alt=""
                      src="/maiatech.svg"
                    />
                    <div className="error-handler">
                      <div className="nhiu-n-lc2">
                        nhiều nỗ lực - một niềm tin
                      </div>
                    </div>
                  </div>
                  <div className="image-processor-wrapper">
                    <div className="image-processor">
                      <div className="function-call">
                        <div className="loop-control">
                          <img
                            className="facebook-icon1"
                            loading="lazy"
                            alt=""
                            src="/facebook-1.svg"
                          />
                          <img
                            className="twitter-icon1"
                            loading="lazy"
                            alt=""
                            src="/twitter-1.svg"
                          />
                          <img
                            className="google-icon1"
                            loading="lazy"
                            alt=""
                            src="/google-1@2x.png"
                          />
                        </div>
                        <div className="constant-value">
                          <div className="copyright-maiatech">
                            {" "}
                            Copyright © MaiATech 2016. 2020.
                          </div>
                        </div>
                      </div>
                      <div className="copyright-maiatech-2016-wrapper">
                        <div className="copyright-maiatech1">
                          Copyright © MaiATech 2016
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="trang-ch-gii-container">
                <p className="trang-ch">Trang chủ</p>
                <p className="gii-thiu1">Giới thiệu</p>
                <p className="dch-v1">Dịch vụ</p>
                <p className="d-n1">Dự án</p>
                <p className="i-ng1">Đội ngũ</p>
                <p className="blank-line12">&nbsp;</p>
              </div>
            </div>
          </div>
          <div className="ellipse-parent">
            <div className="ellipse-div" />
            <div className="frame-child3" />
          </div>
        </footer>
      </section>
      <div className="lin-h-child">
        <div className="frame-parent3">
          <img
            className="group-icon"
            loading="lazy"
            alt=""
            src="/group-115@2x.png"
          />
          <div className="copyright-maiatech-2020-wrapper">
            <div className="copyright-maiatech2">
              {" "}
              Copyright © MaiATech 2020.
            </div>
          </div>
        </div>
      </div>
      <div className="lin-h-item" />
    </div>
  );
};

export default LinH;
